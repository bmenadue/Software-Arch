﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for ProductView.xaml.
    /// </summary>
    public partial class ProductView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the ProductView class.
        /// </summary>
        public ProductView()
        {
            this.InitializeComponent();
        }
    }
}