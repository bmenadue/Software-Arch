﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for LocationView.xaml.
    /// </summary>
    public partial class LocationView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the LocationView class.
        /// </summary>
        public LocationView()
        {
            this.InitializeComponent();
        }
    }
}