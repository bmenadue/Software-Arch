﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for CustomerView.xaml.
    /// </summary>
    public partial class CustomerView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the CustomerView class.
        /// </summary>
        public CustomerView()
        {
            this.InitializeComponent();
        }
    }
}