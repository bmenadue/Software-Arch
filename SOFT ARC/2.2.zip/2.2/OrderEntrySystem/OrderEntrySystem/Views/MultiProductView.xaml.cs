﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for MultiProductView.xaml.
    /// </summary>
    public partial class MultiProductView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the MultiProductView class.
        /// </summary>
        public MultiProductView()
        {
            this.InitializeComponent();
        }
    }
}