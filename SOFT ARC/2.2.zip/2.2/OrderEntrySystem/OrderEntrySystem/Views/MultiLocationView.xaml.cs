﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for MultiLocationView.xaml.
    /// </summary>
    public partial class MultiLocationView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the MultiLocationView class.
        /// </summary>
        public MultiLocationView()
        {
            this.InitializeComponent();
        }
    }
}