﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for MultiCustomerView.xaml.
    /// </summary>
    public partial class MultiCustomerView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the MultiCustomerView class.
        /// </summary>
        public MultiCustomerView()
        {
            this.InitializeComponent();
        }
    }
}