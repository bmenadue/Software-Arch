﻿using System.Windows.Controls;

namespace OrderEntrySystem
{
    /// <summary>
    /// Interaction logic for SelectedItemsView.xaml.
    /// </summary>
    public partial class SelectedItemsView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the SelectedItemsView class.
        /// </summary>
        public SelectedItemsView()
        {
            this.InitializeComponent();
        }
    }
}